﻿﻿'use strict';

import React from 'react';
import ReactMixin from 'react-mixin';
var Reflux = require('reflux');

var Common = require('../../../public/script/common');
import { Spin , Tabs} from 'antd';
import ServiceMsg from '../../../lib/Components/ServiceMsg';

import StatMachinePage from './StatMachinePage';
import StatStatDefinePage from './StatStatDefinePage';
import StatFromToPage from './StatFromToPage';
const TabPane = Tabs.TabPane;

var TstatePage = React.createClass({
	getInitialState : function() {
		return {
			isSelect: true,
			selectKey: '1',
			StatStatDefine:{},
			statFromTo:{},
		}
	},
	selectsRole:function(StatStatDefine){
		this.setState({
			isSelect: true,
			selectKey:'2',
			StatStatDefine:StatStatDefine,
		})
	},
	selectsRoles:function(statFromTo){
		this.setState({
			isSelect: false,
			selectKey:'3',
			statFromTo:statFromTo
		})
	},
	//点击Tab后回调
	onTabClick:function(e){
		this.setState({
			isSelect: true,
			selectKey: e
		});
	
	},
	render : function() {
        var selectKey = this.state.selectKey;
    	var cs = Common.getGridMargin(this, 0);
		return (
			<div className='tab-page' style={{padding: cs.padding}}>
			  <div style={{overflow:'hidden', height:'100%', paddingLeft: '4px'}}>
				  <Tabs defaultActiveKey="1" activeKey={this.state.selectKey} onTabClick={this.onTabClick} tabBarStyle={{paddingLeft: '16px', margin: '-36px 0 0'}} style={{width: '100%', height: '100%', padding: '36px 0 0'}}>
					  <TabPane tab="状态机" key="1" style={{width: '100%', height: '100%'}}>
							<StatMachinePage  selectsRole={this.selectsRole.bind(this)} style={{width: '100%', height: '100%'}}/>
					  </TabPane>
					  <TabPane tab="状态列表" key="2" disabled={this.state.isSelect} style={{width: '100%', height: '100%'}}>
					  		<StatStatDefinePage ref="StatStatDefine" selectsRoles={this.selectsRoles.bind(this)} StatStatDefine={this.state.StatStatDefine.uuid} style={{width: '100%', height: '100%'}}/>
					  </TabPane>
					  <TabPane tab="路由列表" key="3" disabled={this.state.isSelect} style={{width: '100%', height: '100%'}}>
					  		<StatFromToPage ref="statFromTo" InstatFromTo={this.state.statFromTo}  style={{width: '100%', height: '100%'}}/>
					  </TabPane>
				  </Tabs>
			  </div>
		  </div>
		);
	}
});

module.exports = TstatePage;

