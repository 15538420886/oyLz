﻿﻿'use strict';

import React from 'react';
import ReactMixin from 'react-mixin';
var Reflux = require('reflux');

var Common = require('../../../public/script/common');
import { Spin , Tabs} from 'antd';
import ServiceMsg from '../../../lib/Components/ServiceMsg';

const TabPane = Tabs.TabPane;

var TstatePage = React.createClass({
	
	render : function() {
        
		return (
			<div></div>
		)
	}
});

module.exports = TstatePage;


