var Reflux = require('reflux');

var MethodActions = Reflux.createActions([
	'getDevService'
]);

module.exports = MethodActions;

